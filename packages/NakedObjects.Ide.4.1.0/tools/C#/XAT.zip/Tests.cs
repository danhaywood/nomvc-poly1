using System.Linq;
using NakedObjects.Boot;
using NakedObjects.Core.NakedObjectsSystem;
using NakedObjects.EntityObjectStore;
using NakedObjects.Services;
using NakedObjects.Xat;
using NakedObjects.Xat.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace $rootnamespace$

{

    [TestClass()]
    public class $safeitemname$ : AcceptanceTestCase
    {

        #region Constructors
        public $safeitemname$(string name) : base(name) {}

        public $safeitemname$() : this(typeof($safeitemname$).Name) { }
        #endregion

        #region Run configuration
         //Set up the properties in this region exactly the same way as in your Run class

		protected override IServicesInstaller MenuServices
		{
			get
			{
				return new ServicesInstaller(new object[] {});
			}
		}

		protected override IServicesInstaller ContributedActions
		{
			get
			{
				return new ServicesInstaller(new object[] {});
			}
		}

		protected override IServicesInstaller SystemServices
		{
			get
			{
				return new ServicesInstaller(new object[] {});
			}
		}

		protected override IFixturesInstaller Fixtures
		{
			get
			{
				return new FixturesInstaller(new object[] {});
			}
		}

        protected override IObjectPersistorInstaller Persistor
        {
            get { return new EntityPersistorInstaller(); }
        }
        #endregion

        #region Initialize and Cleanup

        [TestInitialize()]
        public void Initialize()
        {
            InitializeNakedObjectsFramework();
            // Use e.g. DatabaseUtils.RestoreDatabase to revert database before each test (or within a [ClassInitialize()] method).
        }

        [TestCleanup()]
        public void  Cleanup()
        {
         	CleanupNakedObjectsFramework();
        }

        #endregion

        [TestMethod()]
        public virtual void Test1() 
        {
        }
    }
}