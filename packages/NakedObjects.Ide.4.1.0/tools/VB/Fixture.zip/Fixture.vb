﻿Imports NakedObjects
Imports NakedObjects.Fixtures

Public Class $safeitemname$

#Region "Injected Services"
    ' This region should contain properties to hold references to any services required by the
    ' object.  Use the 'injs' shortcut to add a new service.


#Region "Injected: Container"

    Protected myContainer As IDomainObjectContainer

    Public Property Container() As IDomainObjectContainer
        Protected Get
            Return myContainer
        End Get
        Set(ByVal value As IDomainObjectContainer)
            myContainer = value
        End Set
    End Property

#End Region

#End Region

    Public Sub Install()

    End Sub

    'Use the 'fact' shortcut to add a new factory method

End Class