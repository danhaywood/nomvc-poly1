Imports NakedObjects.Services
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations
Imports System.Linq

'<DisplayName("")>
    Public Class $safeitemname$
        Inherits AbstractFactoryAndRepository

#Region "Injected Services"
        ' This region should contain properties to hold references to any services required by the
        ' object.  Use the 'injs' shortcut to add a new service.

#End Region

        ' 'fact' shortcut to add a factory method, 
        ' 'alli' for an all-instances method
        ' 'find' for a method to find a single object by query
        ' 'list' for a method to return a list of objects matching a query

    End Class