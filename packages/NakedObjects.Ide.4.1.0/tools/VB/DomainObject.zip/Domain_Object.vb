Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.Linq
Imports NakedObjects

Public Class $safeitemname$

#Region "Injected Services"
    ' This region should contain properties to hold references to any services required by the
    ' object.  Use the 'injs' shortcut to add a new service; 'injc' to add an injected Container

#End Region
#Region "Life Cycle Methods"
    ' This region should contain any of the 'life cycle' convention methods (such as
    ' Created(), Persisted() etc) called by the framework at specified stages in the lifecycle.


#End Region

<Key, Hidden>
Public Overridable Property $safeitemname$Id() As Integer

    'Add properties with 'propo', collections with 'coll', actions with 'act' shortcuts

End Class