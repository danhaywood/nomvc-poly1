Imports System.Linq
Imports NakedObjects.Boot
Imports NakedObjects.Core.NakedObjectsSystem
Imports NakedObjects.EntityObjectStore
Imports NakedObjects.Services
Imports NakedObjects.Xat
Imports NakedObjects.Xat.Database
Imports Microsoft.VisualStudio.TestTools.UnitTesting

	<TestClass()>
	Public Class $safeitemname$
    Inherits AcceptanceTestCase

#Region "Constructors"
    Public Sub New(ByVal name As String)
        MyBase.New(name)
    End Sub

    Public Sub New()
			Me.New(GetType($safeitemname$).Name)
    End Sub
#End Region

#Region "Run configuration"
    'Set up the properties in this region exactly the same way as in your Run class

    Protected Overrides ReadOnly Property MenuServices() As IServicesInstaller
        Get
            Return New ServicesInstaller(New Object() {})
        End Get
    End Property

    Protected Overrides ReadOnly Property ContributedActions() As IServicesInstaller
        Get
            Return New ServicesInstaller(New Object() {})
        End Get
    End Property

    Protected Overrides ReadOnly Property SystemServices() As IServicesInstaller
        Get
            Return New ServicesInstaller(New Object() {})
        End Get
    End Property


    Protected Overrides ReadOnly Property Fixtures() As IFixturesInstaller
        Get
            Return New FixturesInstaller(New Object() {})
        End Get
    End Property

    Protected Overrides ReadOnly Property Persistor As IObjectPersistorInstaller
        Get
            Return New EntityPersistorInstaller()
        End Get
    End Property
#End Region

#Region "Initialize and Cleanup"
    <TestInitialize()>
    Public Sub Initialize()
        InitializeNakedObjectsFramework()
        'Use e.g. DatabaseUtils.RestoreDatabase to revert database before each test (or within a <ClassInitialize()> method).
    End Sub

    <TestCleanup()>
    Public Sub Cleanup()
        CleanupNakedObjectsFramework()
    End Sub

#End Region

    <TestMethod()>
    Public Overridable Sub Test1()
    End Sub
End Class